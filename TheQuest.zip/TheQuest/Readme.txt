			THE QUEST 
	
	The Quest is a turn-based role-playing game with an emphasis on tactics and strategy. The game is completely free. You can give the TheQuest.zip file to anyone you want. You MUST read the Manual.doc file to understand how to play and enjoy the game. I get lots of e-mail from guys who run out money half-way through the game because they had never read the manual and kept making the same mistakes. There are no complex button configurations or settings to memorize, but this is an original game and I strongly suggest that you read the manual before you begin.



   If you have any suggestions, opinions, or anything to say about the game, 
please contact me. I'll try to respond within 1 or 2 days.


My e-mail addresses as of November 2001 : kutsenok@mixi.net  
		      		          kutsenav@rose-hulman.edu   


My mail address is
	
	Mr. Alex Kutsenok
	7922 Sedgewick Pl.
	Fort Wayne, IN 46835
	United States of America	
   	 

			




